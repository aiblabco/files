import os
import sys
import subprocess
import getpass
import urllib
from traitlets.config import (
    HasTraits, Bool, Unicode, Dict, Configurable, Application, catch_config_error
)
from .kampapi import (
    login, storage_credential, mount, ismount, unmount
)

class KampMount(Application):

    config_file = Unicode('/etc/jupyterhub/jupyterhub_config.py')

    access_token = Unicode(help="""
        Access token for KAMP
        """).tag(config=True)
    
    cmd = Unicode('mount', config=True)

    aliases = {
        'access_token': 'KampMount.access_token',
    }

    flags = {
        'status': ({'KampMount': {'cmd': 'status'}}, "KAMP storage mount status"),
        'unmount': ({'KampMount': {'cmd': 'unmount'}}, "umount KAMP storage"),
    }

    @catch_config_error
    def initialize(self, argv=None):
        super().initialize(argv)

        self.load_config_file(self.config_file)

        config = self.config['KampAuthenticator']
        if config == None:
            raise RuntimeError('KampAuthenticator config required.')

    def execute(self):
        self.log.info(self.config)
        self._check_user()

        cmd = self.cmd
        if cmd == 'status':
            if self._ismount():
                print('kamp storage is mounted.')
            else:
                print('kamp storage is not mounted.')
        elif cmd == 'unmount':
            self._unmount()
            print('kamp storage unmounted.')
        else:
            self._mount()
            print('kamp storage mounted.')

    def _mount(self):
        home = self._get_home()
        if not ismount(home):
            config = self.config['KampAuthenticator']
            access_token = self.access_token

            username = config['allowedUsername']

            if not access_token:
                print('input password for user {username}'.format(username=username))
                password = getpass.getpass()

                login_url = config['loginUrl']
                try:
                    login_data = login(login_url, username, password)
                    access_token = login_data['access_token']
                    #self.log.info('access_token={access_token}'.format(access_token=access_token))
                except urllib.error.HTTPError as e:
                    raise RuntimeError("login error:{e}".format(e=e))

            mount_url = config['mountUrl']
            credential_data = storage_credential(mount_url, username, access_token)
            mount(home, credential_data)

    def _unmount(self):
        home = self._get_home()
        if ismount(home):
            unmount(home)

    def _ismount(self):        
        home = self._get_home()
        return ismount(home)

    def _check_user(self):
        user = getpass.getuser()
        #self.log.debug('user={user}'.format(user=user))
        if user != self.config['KampAuthenticator']['user']:
            raise RuntimeError("user {user} is not allowed to mount".format(user=user)) 

    def _get_home(self):
        config = self.config['KampAuthenticator']
        return os.path.join('/home', config['user'])

def main():
    app = KampMount()
    try:
        app.initialize()
        app.execute()
    except Exception as e:
        print(e)
        sys.exit(1)
