from urllib import request, parse
import json
import os
import sys
import subprocess

REGIONS = {
    "KR1": "https://api-storage.cloud.toast.com",
    "KR2": "https://kr2-api-storage.cloud.toast.com",
    "JP1": "https://jp1-api-storage.cloud.toast.com",
}

S3FS_PASSWD_FILE = '.passwd-s3fs'
S3FS_MOUNT_PATH = 'kampstorage'

def login(login_url, username, password):
    data = {
        'username': username,
        'password': password,
    }

    headers = {'Content-Type': 'application/x-www-form-urlencoded'}

    req = request.Request(login_url, headers=headers, data=parse.urlencode(data).encode('utf-8'), method='POST')
    return _get_json(req)

def storage_credential(mount_url, username, access_token):

    mount_data = _get_credential(mount_url, username, access_token)
    #print(f"token_data={token_data}")

    access = mount_data['access']
    secret = mount_data['secret']
    container_id = mount_data['container']
    region = mount_data['region']
        
    return {
        "access": access,
        "secret": secret,
        "container_id": container_id,
        "region": region,
    }

def mount(home, mount_data):
    if ismount(home):
        return

    # save credential
    _save_credential(home, mount_data)

    container_id = mount_data['container_id']
    region = mount_data['region']
    
    mount_path = os.path.join(home, S3FS_MOUNT_PATH)
    passwd_file = os.path.join(home, S3FS_PASSWD_FILE)
    url = REGIONS[region]
    uid = _shell_command(['id', '-u'])
    gid = _shell_command(['id', '-g'])

    if not os.path.exists(mount_path):
        os.makedirs(mount_path)

    #s3fs hello ${HOME}/test -o passwd_file=${HOME}/.passwd-s3fs -o url=https://api-storage.cloud.toast.com -o use_path_request_style -o nonempty    
    command = [
        's3fs',
        container_id,
        mount_path,
        '-o passwd_file=' + passwd_file,
        '-o url=' + url,
        '-o use_path_request_style',
        '-o nonempty',
        '-o uid=' + uid,
        '-o gid=' + gid,
        '-o umask=0007'
    ]
    
    _run_command(command)

def unmount(home):
    if not ismount(home):
        _delete_credential(home)
        return

    mount_path = os.path.join(home, S3FS_MOUNT_PATH)

    command = [
        'fusermount',
        '-u',
        mount_path
    ]

    _run_command(command)
    _delete_credential(home)
        
def ismount(home):
    mount_path = os.path.join(home, S3FS_MOUNT_PATH)
    return os.path.ismount(mount_path)

def _get_credential(mount_url, username, access_token):

    data =  {
        "username": username, "token":access_token
    }

    #headers = {'Content-Type': 'application/json; chearset=utf-8'}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    req = request.Request(mount_url, headers=headers, data=parse.urlencode(data).encode('utf-8'), method='POST')
    #req = request.Request(mount_url, headers=headers, data=json.dumps(data).encode('utf-8'), method='POST')
    return _get_json(req)

def _save_credential(home, mount_data):
    access = mount_data['access']
    secret = mount_data['secret']

    file = os.path.join(home, S3FS_PASSWD_FILE)
    with open(file, mode='w') as f:
        f.write("{access}:{secret}".format(access=access, secret=secret))
    _private_file_mode(file)

def _delete_credential(home):
    file = os.path.join(home, S3FS_PASSWD_FILE)
    os.remove(file)

def _get_json(req):
    res = request.urlopen(req)
    return json.loads(res.read().decode('utf-8'))

def _run_command(command):
    status = os.system(" ".join(command))
    if status != 0:
        sys.exit(1)

def _shell_command(command):
    subproc = subprocess.Popen(" ".join(command), shell=True, stdout=subprocess.PIPE)
    sub_ret = subproc.stdout.read()
    return str(sub_ret,'utf-8')[:-1]

def _private_file_mode(file):
    os.chmod(file, 0o600)
