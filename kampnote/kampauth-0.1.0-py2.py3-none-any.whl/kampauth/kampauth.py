import os
import traceback
from traitlets import Unicode
from jupyterhub.auth import Authenticator
from tornado.ioloop import IOLoop
from tornado.process import Subprocess
from .kampapi import (
    login, storage_credential, mount, ismount, unmount
)

class KampAuthenticator(Authenticator):

    user = Unicode(
        None,
        allow_none=True,
        config=True,
        help="""
        Local User
        """
    )

    allowedUsername = Unicode(
        None,
        allow_none=True,
        config=True,
        help="""
        KAMP Username
        """
    )

    loginUrl = Unicode(
        None,
        allow_none=True,
        config=True,
        help="""
        KAMP Login URL
        """
    )

    mountUrl = Unicode(
        None,
        allow_none=True,
        config=True,
        help="""
        KAMP Mount URL
        """
    )

    async def authenticate(self, handler, data):
        #if self.passwords.get(data['username']) == data['password']:
        #    return data['username']
        username = data['username']
        password = data['password']

        #login allowed
        if username != self.allowedUsername:
            return None

        login_url = self.loginUrl
        mount_url = self.mountUrl

        self.log.debug("login_url={login_url}".format(login_url=login_url))
        self.log.debug("mount_url={mount_url}".format(mount_url=mount_url))

        try:
            token = login(login_url, username, password)
            
            config = self.config['KampAuthenticator']
            if config != None:
                user = config['user']
                home = os.path.join('/home', user)
                if not ismount(home):
                    access_token = token['access_token']
                    command = [
                        'sudo',
                        '-u',
                        user,
                        'kampmount',
                        '--access_token=' + access_token,
                        '&'
                    ]

                    try:
                        os.system(" ".join(command))
                    except Exception as e:
                        self.log.error('KAMP Mount Error-' + str(e))
                        #self.log.error('KAMP Mount Error-' + str(e) + '\n' + traceback.format_exc())

  
            return {
                'name': self.user,
                'auth_state': self._create_auth_state(token),
            }
        except Exception as e:
            self.log.error(e)

    def _create_auth_state(self, token_response):
        access_token = token_response['access_token']
        #refresh_token = token_response.get('refresh_token', None)
        #scope = token_response.get('scope', '')
        #if isinstance(scope, str):
            #scope = scope.split(' ')

        return {
            'access_token': access_token,
            #'refresh_token': refresh_token,
            #'scope': scope,
        }