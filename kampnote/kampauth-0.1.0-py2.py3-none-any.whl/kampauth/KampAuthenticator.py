from IPython.utils.traitlets import Dict
from jupyterhub.auth import Authenticator

class KampAuthenticator(Authenticator):

    passwords = Dict(config=True,
        help="""dict of username:password for authentication"""
    )

    async def authenticate(self, handler, data):
        #if self.passwords.get(data['username']) == data['password']:
        #    return data['username']
        return 'hello'