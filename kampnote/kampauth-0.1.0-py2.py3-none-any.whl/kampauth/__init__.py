"""Top-level package for kampauth."""
from kampauth.kampauth import KampAuthenticator

__author__ = """kampauth"""
__email__ = 'audreyr@example.com'
__version__ = '0.1.0'
__all__ = [KampAuthenticator]